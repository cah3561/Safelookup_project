# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'virus_alarm_widgeteMyEib.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import res_1_rc

class Ui_virus_alarm_widget(object):
    def setupUi(self, virus_alarm_widget):
        if not virus_alarm_widget.objectName():
            virus_alarm_widget.setObjectName(u"virus_alarm_widget")
        virus_alarm_widget.resize(270, 181)
        virus_alarm_widget.setStyleSheet(u"border-image: url(:/main/Desktop - 1.png);")
        self.virus_alarm_widget_logo = QFrame(virus_alarm_widget)
        self.virus_alarm_widget_logo.setObjectName(u"virus_alarm_widget_logo")
        self.virus_alarm_widget_logo.setGeometry(QRect(110, 10, 41, 41))
        self.virus_alarm_widget_logo.setStyleSheet(u"border-image: url(:/main/alarm_icon.png);")
        self.virus_alarm_widget_logo.setFrameShape(QFrame.NoFrame)
        self.virus_alarm_widget_war = QPushButton(virus_alarm_widget)
        self.virus_alarm_widget_war.setObjectName(u"virus_alarm_widget_war")
        self.virus_alarm_widget_war.setGeometry(QRect(10, 70, 111, 71))
        self.virus_alarm_widget_war.setCursor(QCursor(Qt.PointingHandCursor))
        self.virus_alarm_widget_war.setStyleSheet(u"border-image: url(:/main/00 Button (11).png);")
        self.virus_alarm_widget_del = QPushButton(virus_alarm_widget)
        self.virus_alarm_widget_del.setObjectName(u"virus_alarm_widget_del")
        self.virus_alarm_widget_del.setGeometry(QRect(140, 70, 111, 71))
        self.virus_alarm_widget_del.setCursor(QCursor(Qt.PointingHandCursor))
        self.virus_alarm_widget_del.setStyleSheet(u"border-image: url(:/main/00 Button (12).png);")

        self.retranslateUi(virus_alarm_widget)

        QMetaObject.connectSlotsByName(virus_alarm_widget)
    # setupUi

    def retranslateUi(self, virus_alarm_widget):
        virus_alarm_widget.setWindowTitle(QCoreApplication.translate("virus_alarm_widget", u"Form", None))
        self.virus_alarm_widget_war.setText("")
        self.virus_alarm_widget_del.setText("")
    # retranslateUi

