# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main_windowHiwdCZ.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################
from QtDesigner import *
from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *
from PySide6.QtWebEngineWidgets import *
import sys 


import res_1_rc

# 메인 화면
class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(806, 590)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.mainwindow_frame = QFrame(self.centralwidget)
        self.mainwindow_frame.setObjectName(u"mainwindow_frame")
        self.mainwindow_frame.setGeometry(QRect(0, 0, 801, 571))
        self.mainwindow_frame.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.mainwindow_frame.setFrameShape(QFrame.NoFrame)
        self.helpcheck = QPushButton(self.mainwindow_frame)
        self.helpcheck.setObjectName(u"helpcheck")
        self.helpcheck.setGeometry(QRect(50, 30, 90, 60))
        self.helpcheck.setCursor(QCursor(Qt.PointingHandCursor))
        self.helpcheck.setStyleSheet(u"border-image: url(./00 Button (4).png);")
        self.helpcheck.clicked.connect(self.button1Function)
        self.viruscheck = QPushButton(self.mainwindow_frame)
        self.viruscheck.setObjectName(u"viruscheck")
        self.viruscheck.setGeometry(QRect(350, 30, 90, 60))
        self.viruscheck.setCursor(QCursor(Qt.PointingHandCursor))
        self.viruscheck.setStyleSheet(u"border-image: url(./00 Button (1).png);")
        self.viruscheck.clicked.connect(self.button2Function)
        self.historycheck = QPushButton(self.mainwindow_frame)
        self.historycheck.setObjectName(u"historycheck")
        self.historycheck.setGeometry(QRect(500, 30, 90, 60))
        self.historycheck.setCursor(QCursor(Qt.PointingHandCursor))
        self.historycheck.setStyleSheet(u"border-image: url(./00 Button (2).png);")
        self.historycheck.clicked.connect(self.button3Function)
        self.settingcheck = QPushButton(self.mainwindow_frame)
        self.settingcheck.setObjectName(u"settingcheck")
        self.settingcheck.setGeometry(QRect(640, 30, 90, 60))
        self.settingcheck.setCursor(QCursor(Qt.PointingHandCursor))
        self.settingcheck.setMouseTracking(False)
        self.settingcheck.setAcceptDrops(False)
        self.settingcheck.setStyleSheet(u"\n"
"border-image: url(./00 Button (3).png);")
        self.settingcheck.setAutoDefault(False)
        self.settingcheck.clicked.connect(self.button4Function)
        self.mainwindow_frame_logo = QFrame(self.mainwindow_frame)
        self.mainwindow_frame_logo.setObjectName(u"mainwindow_frame_logo")
        self.mainwindow_frame_logo.setGeometry(QRect(190, 240, 411, 121))
        self.mainwindow_frame_logo.setStyleSheet(u"border-image: url(./Safe Lookup.png);")
        self.mainwindow_frame_logo.setFrameShape(QFrame.NoFrame)
        self.urlcheck = QPushButton(self.mainwindow_frame)
        self.urlcheck.setObjectName(u"urlcheck")
        self.urlcheck.setGeometry(QRect(200, 30, 90, 60))
        self.urlcheck.setCursor(QCursor(Qt.PointingHandCursor))
        self.urlcheck.setStyleSheet(u"border-image: url(./00 Button (5).png);")
        self.urlcheck.setCheckable(False)
        self.urlcheck.setChecked(False)
        self.urlcheck.clicked.connect(self.button5Function)
        MainWindow.setCentralWidget(self.centralwidget)
        self.mainwindow_bar = QStatusBar(MainWindow)
        self.mainwindow_bar.setObjectName(u"mainwindow_bar")
        MainWindow.setStatusBar(self.mainwindow_bar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.helpcheck.setText("")
        self.viruscheck.setText("")
        self.historycheck.setText("")
        self.settingcheck.setText("")
        self.urlcheck.setText("")
    # retranslateUi

    # help widget func
    def button1Function(self) :  
         self.help_widget = QWidget()
         self.ui_help = Ui_help_widget()
         self.ui_help.setupUi_help(self.help_widget)
         self.help_widget.show()
         
    # virus widget func     
    def button2Function(self) :  
         self.virus_widget = QWidget()
         self.ui_virus = Ui_virus_widget()
         self.ui_virus.setupUi_virus(self.virus_widget)
         self.virus_widget.show()
         
    # history widget func
    def button3Function(self) :  
         self.history_widget = QWidget()
         self.ui_history = Ui_history_widget()
         self.ui_history.setupUi_history(self.history_widget)
         self.history_widget.show()
         
    # setting widget func
    def button4Function(self) :  
         self.settings = QWidget()
         self.ui_settings = Ui_settings()
         self.ui_settings.setupUi_settings(self.settings)
         self.settings.show()
         
    # url widget func
    def button5Function(self) :  
         self.url_widget = QWidget()
         self.ui_url = Ui_url_check_widget()
         self.ui_url.setupUi_url(self.url_widget)
         self.url_widget.show()
            
# 도움말 위젯                
class Ui_help_widget(object):
    def setupUi_help(self, help_widget):
        if not help_widget.objectName():
            help_widget.setObjectName(u"help_widget")
        help_widget.resize(603, 634)
        help_widget.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.help_widget_logo = QFrame(help_widget)
        self.help_widget_logo.setObjectName(u"help_widget_logo")
        self.help_widget_logo.setGeometry(QRect(110, 10, 381, 91))
        self.help_widget_logo.setStyleSheet(u"border-image: url(./Safe Lookup.png);")
        self.help_widget_logo.setFrameShape(QFrame.NoFrame)
        self.help_widget_name = QLabel(help_widget)
        self.help_widget_name.setObjectName(u"help_widget_name")
        self.help_widget_name.setGeometry(QRect(250, 100, 91, 31))
        self.help_widget_name.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")
        self.help_widget_name.setAlignment(Qt.AlignCenter)
        self.help_widget_text = QTextBrowser(help_widget)
        self.help_widget_text.setObjectName(u"help_widget_text")
        self.help_widget_text.setGeometry(QRect(80, 150, 441, 441))

        self.retranslateUi(help_widget)

        QMetaObject.connectSlotsByName(help_widget)
    # setupUi

    def retranslateUi(self, help_widget):
        help_widget.setWindowTitle(QCoreApplication.translate("help_widget", u"Form", None))
        self.help_widget_name.setText(QCoreApplication.translate("help_widget", u"\ub3c4\uc6c0\ub9d0", None))
        self.help_widget_text.setHtml(QCoreApplication.translate("help_widget", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Gulim'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600; color:#eaeaea;\">URL Check </span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:14pt; font-weight:600; color:#eaeaea;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-inde"
                        "nt:0px;\"><span style=\" color:#eaeaea;\">1. \ud655\uc778\ud560 \uc0ac\uc774\ud2b8\uc758 URL\uc744 \ubcf5\uc0ac\ud55c\ub2e4.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">2. \ud655\uc778\ud560 \uc0ac\uc774\ud2b8\uc758 URL\uc744 URL Check \ud654\uba74\uc5d0 \ubd99\uc5ec \ub123\ub294\ub2e4.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">3. \uac80\uc0ac \uacb0\uacfc\ub97c \ud655\uc778\ud55c\ub2e4.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; color:#eaeaea;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600; color:#eaeaea;\">Virus C"
                        "heck</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:14pt; font-weight:600; color:#eaeaea;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">1. \ud655\uc778\ud560 \ud30c\uc77c\uc744 Virus Check \ud654\uba74\uc5d0 \ub04c\uc5b4\uc624\uac70\ub098 \ubd88\ub7ec\uc628\ub2e4.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">2. \uac80\uc0ac \uacb0\uacfc\ub97c \ud655\uc778\ud55c\ub2e4.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">3. \uc758\uc2ec\uc774 \uac00\ub294 \ud30c\uc77c\ub85c \ud655\uc778\ub420 \uacbd\uc6b0 \uacb0\uacfc\ub97c \ud655\uc778"
                        "\ud558\uace0 \uc0ad\uc81c\ud55c\ub2e4.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; color:#eaeaea;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600; color:#eaeaea;\">History</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:14pt; font-weight:600; color:#eaeaea;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">1. \uc774\uc804\uc758 \uac80\uc0ac \uc774\ub825\uc744 \ud655\uc778\ud560 \uc218 \uc788\ub2e4.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0"
                        "px;\"><span style=\" color:#eaeaea;\">2. 'x' \ubc84\ud2bc\uc744 \ub20c\ub7ec \uc774\ub825\uc744 \uc0ad\uc81c\ud560 \uc218 \uc788\ub2e4.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; color:#eaeaea;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:14pt; font-weight:600; color:#eaeaea;\">Settings</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:14pt; font-weight:600; color:#eaeaea;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">1. \uae30\ub85d \uc5ec\ubd80\ub97c \uc124\uc815\ud560 \uc218 \uc788\ub2e4.</span></p>\n"
"<p style=\" margin-top:0px; margin-b"
                        "ottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">2. \uae30\ub85d\uc744 .txt \ud30c\uc77c\ub85c \ub0b4\ubcf4\ub0bc \uc218 \uc788\ub2e4.</span></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">3. \uae30\ub85d\uc774 \uac00\ub4dd\ucc28\uba74 \uc790\ub3d9\uc73c\ub85c \uc0ad\uc81c\ud558\ub294 \uae30\ub2a5\uc744 \ucd94\uac00\ud560 \uc218 \uc788\ub2e4.</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; color:#eaeaea;\"><br /></p>\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#eaeaea;\">\uc774\uc6a9\ud574\uc8fc\uc154\uc11c \uac10\uc0ac\ud569\ub2c8\ub2e4.         \ubc84\uc804 \uc815\ubcf4: 1.0.0.1</span></p></body></html>", None))
    # retranslateUi

# 기록 위젯    
class Ui_history_widget(object):
    def setupUi_history(self, history_widget):
        if not history_widget.objectName():
            history_widget.setObjectName(u"history_widget")
        history_widget.resize(752, 442)
        history_widget.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.history_widget_logo = QFrame(history_widget)
        self.history_widget_logo.setObjectName(u"history_widget_logo")
        self.history_widget_logo.setGeometry(QRect(190, 20, 381, 91))
        self.history_widget_logo.setStyleSheet(u"border-image: url(./Safe Lookup.png);")
        self.history_widget_logo.setFrameShape(QFrame.NoFrame)
        self.history_widget_text = QTextBrowser(history_widget)
        self.history_widget_text.setObjectName(u"history_widget_text")
        self.history_widget_text.setGeometry(QRect(90, 140, 581, 271))
        self.history_widget_scrollarea = QScrollArea(history_widget)
        self.history_widget_scrollarea.setObjectName(u"history_widget_scrollarea")
        self.history_widget_scrollarea.setGeometry(QRect(100, 150, 561, 251))
        self.history_widget_scrollarea.setWidgetResizable(True)
        self.history_widget_contents = QWidget()
        self.history_widget_contents.setObjectName(u"history_widget_contents")
        self.history_widget_contents.setGeometry(QRect(0, 0, 561, 251))
        self.history_widget_scrollarea.setWidget(self.history_widget_contents)
        self.history_widget_name = QLabel(history_widget)
        self.history_widget_name.setObjectName(u"history_widget_name")
        self.history_widget_name.setGeometry(QRect(350, 110, 71, 21))
        self.history_widget_name.setStyleSheet(u"font: 14pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")
        self.history_widget_name.setAlignment(Qt.AlignCenter)

        self.retranslateUi(history_widget)

        QMetaObject.connectSlotsByName(history_widget)
    # setupUi

    def retranslateUi(self, history_widget):
        history_widget.setWindowTitle(QCoreApplication.translate("history_widget", u"Form", None))
        self.history_widget_name.setText(QCoreApplication.translate("history_widget", u"history", None))
    # retranslateUi    

# 세팅 위젯
class Ui_settings(object):
    def setupUi_settings(self, settings):
        if not settings.objectName():
            settings.setObjectName(u"settings")
        settings.resize(313, 216)
        settings.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.settings_out = QRadioButton(settings)
        self.settings_out.setObjectName(u"settings_out")
        self.settings_out.setGeometry(QRect(60, 90, 201, 21))
        self.settings_out.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")
        self.settings_out.setAutoExclusive(False)
        self.settings_auto = QRadioButton(settings)
        self.settings_auto.setObjectName(u"settings_auto")
        self.settings_auto.setGeometry(QRect(60, 130, 201, 21))
        self.settings_auto.setCursor(QCursor(Qt.PointingHandCursor))
        self.settings_auto.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255)")
        self.settings_auto.setAutoExclusive(False)
        self.settings_accept = QPushButton(settings)
        self.settings_accept.setObjectName(u"settings_accept")
        self.settings_accept.setGeometry(QRect(60, 170, 75, 24))
        self.settings_accept.setCursor(QCursor(Qt.PointingHandCursor))
        self.settings_accept.setCheckable(False)
        self.settings_accept.setFlat(False)
        self.psettings_deny = QPushButton(settings)
        self.psettings_deny.setObjectName(u"psettings_deny")
        self.psettings_deny.setGeometry(QRect(190, 170, 75, 24))
        self.psettings_deny.setCursor(QCursor(Qt.PointingHandCursor))
        self.settings_name = QLabel(settings)
        self.settings_name.setObjectName(u"settings_name")
        self.settings_name.setGeometry(QRect(100, 10, 121, 31))
        font = QFont()
        font.setFamily(u"\uace0\ub3c4 B")
        font.setPointSize(20)
        font.setBold(False)
        font.setItalic(False)
        self.settings_name.setFont(font)
        self.settings_name.setStyleSheet(u"color: rgb(227, 227, 227);\n"
"font: 20pt \"\uace0\ub3c4 B\";")
        self.settings_name.setAlignment(Qt.AlignCenter)
        self.settings_history = QRadioButton(settings)
        self.settings_history.setObjectName(u"settings_history")
        self.settings_history.setEnabled(True)
        self.settings_history.setGeometry(QRect(60, 50, 201, 21))
        self.settings_history.setCursor(QCursor(Qt.PointingHandCursor))
        self.settings_history.setFocusPolicy(Qt.WheelFocus)
        self.settings_history.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")
        self.settings_history.setCheckable(True)
        self.settings_history.setChecked(False)
        self.settings_history.setAutoExclusive(False)
        self.retranslateUi(settings)

        QMetaObject.connectSlotsByName(settings)
    # setupUi

    def retranslateUi(self, settings):
        settings.setWindowTitle(QCoreApplication.translate("settings", u"Form", None))
        self.settings_out.setText(QCoreApplication.translate("settings", u"\uac80\uc0ac \ub0b4\uc6a9 \ub0b4\ubcf4\ub0b4\uae30", None))
        self.settings_auto.setText(QCoreApplication.translate("settings", u" \uc790\ub3d9 \uc0ad\uc81c", None))
        self.settings_accept.setText(QCoreApplication.translate("settings", u"\uc801\uc6a9", None))
        self.psettings_deny.setText(QCoreApplication.translate("settings", u"\ucde8\uc18c", None))
        self.settings_name.setText(QCoreApplication.translate("settings", u"Settings", None))
        self.settings_history.setText(QCoreApplication.translate("settings", u"\uac80\uc0ac \ub0b4\uc6a9 \uae30\ub85d\ud558\uae30", None))
    # retranslateUi

# 바이러스 체크 위젯
class Ui_virus_widget(object):
    def setupUi_virus(self, virus_widget_main):
        if not virus_widget_main.objectName():
            virus_widget_main.setObjectName(u"virus_widget_main")
        virus_widget_main.resize(837, 547)
        virus_widget_main.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.virus_widget_name_logo = QLabel(virus_widget_main)
        self.virus_widget_name_logo.setObjectName(u"virus_widget_name_logo")
        self.virus_widget_name_logo.setGeometry(QRect(350, 30, 121, 51))
        self.virus_widget_name_logo.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")
        self.virus_widget_name_logo.setAlignment(Qt.AlignCenter)
        self.virus_widget_check = QPushButton(virus_widget_main)
        self.virus_widget_check.setObjectName(u"virus_widget_check")
        self.virus_widget_check.setGeometry(QRect(580, 410, 61, 31))
        self.virus_widget_check.setStyleSheet(u"\n"
"border-image: url(./Button-New.png);")
        self.virus_widget_bring = QListWidget(virus_widget_main)
        self.virus_widget_bring.setObjectName(u"virus_widget_bring")
        self.virus_widget_bring.setGeometry(QRect(240, 280, 331, 161))
        self.virus_widget_bring.setAcceptDrops(True)
        self.virus_widget_bring.setDragEnabled(True)
        self.virus_widget_bring.setDragDropOverwriteMode(True)
        self.virus_widget_upload = QToolButton(virus_widget_main)
        self.virus_widget_upload.setObjectName(u"virus_widget_upload")
        self.virus_widget_upload.setGeometry(QRect(590, 380, 24, 22))
        self.virus_widget_bring_logo = QLabel(virus_widget_main)
        self.virus_widget_bring_logo.setObjectName(u"virus_widget_bring_logo")
        self.virus_widget_bring_logo.setGeometry(QRect(380, 350, 51, 31))
        self.virus_widget_bring_logo.setStyleSheet(u"border-image: url(./Viruscheck_icon.png);")
        self.virus_widget_logo = QFrame(virus_widget_main)
        self.virus_widget_logo.setObjectName(u"virus_widget_logo")
        self.virus_widget_logo.setGeometry(QRect(230, 130, 381, 91))
        self.virus_widget_logo.setStyleSheet(u"border-image: url(./Safe Lookup.png);")
        self.virus_widget_logo.setFrameShape(QFrame.NoFrame)

        self.retranslateUi(virus_widget_main)

        QMetaObject.connectSlotsByName(virus_widget_main)
    # setupUi

    def retranslateUi(self, virus_widget_main):
        virus_widget_main.setWindowTitle(QCoreApplication.translate("virus_widget_main", u"Form", None))
        self.virus_widget_name_logo.setText(QCoreApplication.translate("virus_widget_main", u"Virus Check", None))
        self.virus_widget_check.setText("")
        self.virus_widget_upload.setText(QCoreApplication.translate("virus_widget_main", u"...", None))
        self.virus_widget_bring_logo.setText("")
    # retranslateUi

# url 체크 위젯
class Ui_url_check_widget(object):
    def setupUi_url(self, url_check_widget):
        if not url_check_widget.objectName():
            url_check_widget.setObjectName(u"url_check_widget")
        url_check_widget.resize(605, 444)
        url_check_widget.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.url_check_widget_url = QLineEdit(url_check_widget)
        self.url_check_widget_url.setObjectName(u"url_check_widget_url")
        self.url_check_widget_url.setGeometry(QRect(70, 280, 371, 31))
        self.url_check_widget_check = QPushButton(url_check_widget)
        self.url_check_widget_check.setObjectName(u"url_check_widget_check")
        self.url_check_widget_check.setGeometry(QRect(460, 280, 61, 31))
        self.url_check_widget_check.setStyleSheet(u"\n"
"border-image: url(./Button-New.png);")
        self.url_check_widget_logo = QFrame(url_check_widget)
        self.url_check_widget_logo.setObjectName(u"url_check_widget_logo")
        self.url_check_widget_logo.setGeometry(QRect(130, 110, 331, 91))
        self.url_check_widget_logo.setStyleSheet(u"border-image: url(./Safe Lookup.png);")
        self.url_check_widget_logo.setFrameShape(QFrame.StyledPanel)
        self.url_check_widget_logo.setFrameShadow(QFrame.Raised)
        self.url_check_widget_name = QLabel(url_check_widget)
        self.url_check_widget_name.setObjectName(u"url_check_widget_name")
        self.url_check_widget_name.setGeometry(QRect(240, 50, 111, 31))
        self.url_check_widget_name.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")

        self.retranslateUi(url_check_widget)

        QMetaObject.connectSlotsByName(url_check_widget)
    # setupUi

    def retranslateUi(self, url_check_widget):
        url_check_widget.setWindowTitle(QCoreApplication.translate("url_check_widget", u"Form", None))
        self.url_check_widget_check.setText("")
        self.url_check_widget_name.setText(QCoreApplication.translate("url_check_widget", u"URL Check ", None))
    # retranslateUi

# 바이러스 감지 알람 위젯
class Ui_virus_alarm_widget(object):
    def setupUi(self, virus_alarm_widget):
        if not virus_alarm_widget.objectName():
            virus_alarm_widget.setObjectName(u"virus_alarm_widget")
        virus_alarm_widget.resize(270, 181)
        virus_alarm_widget.setStyleSheet(u"border-image: url(.Desktop - 1.png);")
        self.virus_alarm_widget_logo = QFrame(virus_alarm_widget)
        self.virus_alarm_widget_logo.setObjectName(u"virus_alarm_widget_logo")
        self.virus_alarm_widget_logo.setGeometry(QRect(110, 10, 41, 41))
        self.virus_alarm_widget_logo.setStyleSheet(u"border-image: url(./alarm_icon.png);")
        self.virus_alarm_widget_logo.setFrameShape(QFrame.NoFrame)
        self.virus_alarm_widget_war = QPushButton(virus_alarm_widget)
        self.virus_alarm_widget_war.setObjectName(u"virus_alarm_widget_war")
        self.virus_alarm_widget_war.setGeometry(QRect(10, 70, 111, 71))
        self.virus_alarm_widget_war.setCursor(QCursor(Qt.PointingHandCursor))
        self.virus_alarm_widget_war.setStyleSheet(u"border-image: url(./00 Button (11).png);")
        self.virus_alarm_widget_del = QPushButton(virus_alarm_widget)
        self.virus_alarm_widget_del.setObjectName(u"virus_alarm_widget_del")
        self.virus_alarm_widget_del.setGeometry(QRect(140, 70, 111, 71))
        self.virus_alarm_widget_del.setCursor(QCursor(Qt.PointingHandCursor))
        self.virus_alarm_widget_del.setStyleSheet(u"border-image: url(./00 Button (12).png);")

        self.retranslateUi(virus_alarm_widget)

        QMetaObject.connectSlotsByName(virus_alarm_widget)
    # setupUi

    def retranslateUi(self, virus_alarm_widget):
        virus_alarm_widget.setWindowTitle(QCoreApplication.translate("virus_alarm_widget", u"Form", None))
        self.virus_alarm_widget_war.setText("")
        self.virus_alarm_widget_del.setText("")
    # retranslateUi

#url 감지 알람 위젯
class Ui_url_alarm(object):
    def setupUi(self, url_alarm):
        if not url_alarm.objectName():
            url_alarm.setObjectName(u"url_alarm")
        url_alarm.resize(276, 181)
        url_alarm.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.url_alarm_war = QPushButton(url_alarm)
        self.url_alarm_war.setObjectName(u"url_alarm_war")
        self.url_alarm_war.setGeometry(QRect(80, 80, 111, 71))
        self.url_alarm_war.setCursor(QCursor(Qt.PointingHandCursor))
        self.url_alarm_war.setStyleSheet(u"border-image: url(./00 Button (11).png);")
        self.url_alarm_logo = QFrame(url_alarm)
        self.url_alarm_logo.setObjectName(u"url_alarm_logo")
        self.url_alarm_logo.setGeometry(QRect(110, 20, 41, 41))
        self.url_alarm_logo.setStyleSheet(u"border-image: url(./alarm_icon.png);")
        self.url_alarm_logo.setFrameShape(QFrame.NoFrame)

        self.retranslateUi(url_alarm)

        QMetaObject.connectSlotsByName(url_alarm)
    # setupUi

    def retranslateUi(self, url_alarm):
        url_alarm.setWindowTitle(QCoreApplication.translate("url_alarm", u"Form", None))
        self.url_alarm_war.setText("")
    # retranslateUi    

# 안전 확인 알람 위젯   
class Ui_safe_alarm_widget(object):
    def setupUi_safe_alarm(self, safe_alarm_widget):
        if not safe_alarm_widget.objectName():
            safe_alarm_widget.setObjectName(u"safe_alarm_widget")
        safe_alarm_widget.resize(269, 181)
        safe_alarm_widget.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.safe_alarm_widget_close = QPushButton(safe_alarm_widget)
        self.safe_alarm_widget_close.setObjectName(u"safe_alarm_widget_close")
        self.safe_alarm_widget_close.setGeometry(QRect(80, 50, 111, 71))
        self.safe_alarm_widget_close.setCursor(QCursor(Qt.PointingHandCursor))
        self.safe_alarm_widget_close.setStyleSheet(u"border-image: url(./00 Button (10).png);")

        self.retranslateUi(safe_alarm_widget)

        QMetaObject.connectSlotsByName(safe_alarm_widget)
    # setupUi

    def retranslateUi(self, safe_alarm_widget):
        safe_alarm_widget.setWindowTitle(QCoreApplication.translate("safe_alarm_widget", u"Form", None))
        self.safe_alarm_widget_close.setText("")
    # retranslateUi      

# 상세 확인 위젯
class Ui_des_widget(object):
    def setupUi(self, des_widget):
        if not des_widget.objectName():
            des_widget.setObjectName(u"des_widget")
        des_widget.resize(673, 472)
        des_widget.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.des_widget_name = QLabel(des_widget)
        self.des_widget_name.setObjectName(u"des_widget_name")
        self.des_widget_name.setGeometry(QRect(200, 30, 261, 31))
        font = QFont()
        font.setFamily(u"\uace0\ub3c4 B")
        font.setPointSize(22)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.des_widget_name.setFont(font)
        self.des_widget_name.setStyleSheet(u"color: rgb(204, 204, 204);\n"
"font: 22pt \"\uace0\ub3c4 B\";")
        self.des_widget_name.setAlignment(Qt.AlignCenter)
        self.des_widget_close = QPushButton(des_widget)
        self.des_widget_close.setObjectName(u"des_widget_close")
        self.des_widget_close.setGeometry(QRect(470, 30, 51, 41))
        self.des_widget_close.setCursor(QCursor(Qt.PointingHandCursor))
        self.des_widget_close.setStyleSheet(u"border-image: url(./exit_icon.png);")
        self.des_widget_web = QWebEngineView(des_widget)
        self.des_widget_web.setObjectName(u"des_widget_web")
        self.des_widget_web.setGeometry(QRect(90, 90, 491, 351))
        self.des_widget_web.setUrl(QUrl(u"about:blank"))
        self.des_widget_scrollarea = QScrollArea(des_widget)
        self.des_widget_scrollarea.setObjectName(u"des_widget_scrollarea")
        self.des_widget_scrollarea.setGeometry(QRect(100, 100, 471, 331))
        self.des_widget_scrollarea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 471, 331))
        self.des_widget_scrollarea.setWidget(self.scrollAreaWidgetContents)

        self.retranslateUi(des_widget)

        QMetaObject.connectSlotsByName(des_widget)
    # setupUi

    def retranslateUi(self, des_widget):
        des_widget.setWindowTitle(QCoreApplication.translate("des_widget", u"Form", None))
#if QT_CONFIG(whatsthis)
        self.des_widget_name.setWhatsThis(QCoreApplication.translate("des_widget", u"<html><head/><body><p><br/></p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.des_widget_name.setText(QCoreApplication.translate("des_widget", u"Details of Reports", None))
        self.des_widget_close.setText("")
    # retranslateUi

    


if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    MainWindow = QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    
    MainWindow.show()
    
    sys.exit(app.exec())