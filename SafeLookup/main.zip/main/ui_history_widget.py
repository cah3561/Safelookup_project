# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'history_widgetaPoCAL.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import res_1_rc

class Ui_history_widget(object):
    def setupUi(self, history_widget):
        if not history_widget.objectName():
            history_widget.setObjectName(u"history_widget")
        history_widget.resize(752, 442)
        history_widget.setStyleSheet(u"border-image: url(:/main/Desktop - 1.png);")
        self.history_widget_logo = QFrame(history_widget)
        self.history_widget_logo.setObjectName(u"history_widget_logo")
        self.history_widget_logo.setGeometry(QRect(190, 20, 381, 91))
        self.history_widget_logo.setStyleSheet(u"border-image: url(:/main/Safe Lookup.png);")
        self.history_widget_logo.setFrameShape(QFrame.NoFrame)
        self.history_widget_text = QTextBrowser(history_widget)
        self.history_widget_text.setObjectName(u"history_widget_text")
        self.history_widget_text.setGeometry(QRect(90, 140, 581, 271))
        self.history_widget_scrollarea = QScrollArea(history_widget)
        self.history_widget_scrollarea.setObjectName(u"history_widget_scrollarea")
        self.history_widget_scrollarea.setGeometry(QRect(100, 150, 561, 251))
        self.history_widget_scrollarea.setWidgetResizable(True)
        self.history_widget_contents = QWidget()
        self.history_widget_contents.setObjectName(u"history_widget_contents")
        self.history_widget_contents.setGeometry(QRect(0, 0, 561, 251))
        self.history_widget_scrollarea.setWidget(self.history_widget_contents)
        self.history_widget_name = QLabel(history_widget)
        self.history_widget_name.setObjectName(u"history_widget_name")
        self.history_widget_name.setGeometry(QRect(350, 110, 71, 21))
        self.history_widget_name.setStyleSheet(u"font: 14pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")
        self.history_widget_name.setAlignment(Qt.AlignCenter)

        self.retranslateUi(history_widget)

        QMetaObject.connectSlotsByName(history_widget)
    # setupUi

    def retranslateUi(self, history_widget):
        history_widget.setWindowTitle(QCoreApplication.translate("history_widget", u"Form", None))
        self.history_widget_name.setText(QCoreApplication.translate("history_widget", u"history", None))
    # retranslateUi

