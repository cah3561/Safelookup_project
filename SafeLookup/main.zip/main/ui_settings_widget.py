# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'settings_widgetEoJZoo.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import res_1_rc

class Ui_settings(object):
    def setupUi(self, settings):
        if not settings.objectName():
            settings.setObjectName(u"settings")
        settings.resize(313, 216)
        settings.setStyleSheet(u"border-image: url(:/main/Desktop - 1.png);")
        self.settings_out = QRadioButton(settings)
        self.settings_out.setObjectName(u"settings_out")
        self.settings_out.setGeometry(QRect(60, 90, 201, 21))
        self.settings_out.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")
        self.settings_auto = QRadioButton(settings)
        self.settings_auto.setObjectName(u"settings_auto")
        self.settings_auto.setGeometry(QRect(60, 130, 201, 21))
        self.settings_auto.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255)")
        self.settings_accept = QPushButton(settings)
        self.settings_accept.setObjectName(u"settings_accept")
        self.settings_accept.setGeometry(QRect(60, 170, 75, 24))
        self.psettings_deny = QPushButton(settings)
        self.psettings_deny.setObjectName(u"psettings_deny")
        self.psettings_deny.setGeometry(QRect(190, 170, 75, 24))
        self.settings_name = QLabel(settings)
        self.settings_name.setObjectName(u"settings_name")
        self.settings_name.setGeometry(QRect(100, 10, 121, 31))
        font = QFont()
        font.setFamily(u"\uace0\ub3c4 B")
        font.setPointSize(20)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.settings_name.setFont(font)
        self.settings_name.setStyleSheet(u"color: rgb(227, 227, 227);\n"
"font: 20pt \"\uace0\ub3c4 B\";")
        self.settings_name.setAlignment(Qt.AlignCenter)
        self.settings_history = QRadioButton(settings)
        self.settings_history.setObjectName(u"settings_history")
        self.settings_history.setGeometry(QRect(60, 50, 201, 21))
        self.settings_history.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")

        self.retranslateUi(settings)

        QMetaObject.connectSlotsByName(settings)
    # setupUi

    def retranslateUi(self, settings):
        settings.setWindowTitle(QCoreApplication.translate("settings", u"Form", None))
        self.settings_out.setText(QCoreApplication.translate("settings", u"\uac80\uc0ac \ub0b4\uc6a9 \ub0b4\ubcf4\ub0b4\uae30", None))
        self.settings_auto.setText(QCoreApplication.translate("settings", u" \uc790\ub3d9 \uc0ad\uc81c", None))
        self.settings_accept.setText(QCoreApplication.translate("settings", u"\uc801\uc6a9", None))
        self.psettings_deny.setText(QCoreApplication.translate("settings", u"\ucde8\uc18c", None))
        self.settings_name.setText(QCoreApplication.translate("settings", u"Settings", None))
        self.settings_history.setText(QCoreApplication.translate("settings", u"\uac80\uc0ac \ub0b4\uc6a9 \uae30\ub85d\ud558\uae30", None))
    # retranslateUi

