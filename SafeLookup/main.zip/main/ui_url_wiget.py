# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'url_wigetCpHSvq.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import res_1_rc

class Ui_url_check_widget(object):
    def setupUi(self, url_check_widget):
        if not url_check_widget.objectName():
            url_check_widget.setObjectName(u"url_check_widget")
        url_check_widget.resize(605, 444)
        url_check_widget.setStyleSheet(u"border-image: url(:/main/Desktop - 1.png);")
        self.url_check_widget_url = QLineEdit(url_check_widget)
        self.url_check_widget_url.setObjectName(u"url_check_widget_url")
        self.url_check_widget_url.setGeometry(QRect(70, 280, 371, 31))
        self.url_check_widget_check = QPushButton(url_check_widget)
        self.url_check_widget_check.setObjectName(u"url_check_widget_check")
        self.url_check_widget_check.setGeometry(QRect(460, 280, 61, 31))
        self.url_check_widget_check.setStyleSheet(u"\n"
"border-image: url(:/main/Button-New.png);")
        self.url_check_widget_logo = QFrame(url_check_widget)
        self.url_check_widget_logo.setObjectName(u"url_check_widget_logo")
        self.url_check_widget_logo.setGeometry(QRect(130, 110, 331, 91))
        self.url_check_widget_logo.setStyleSheet(u"border-image: url(:/main/Safe Lookup.png);")
        self.url_check_widget_logo.setFrameShape(QFrame.StyledPanel)
        self.url_check_widget_logo.setFrameShadow(QFrame.Raised)
        self.url_check_widget_name = QLabel(url_check_widget)
        self.url_check_widget_name.setObjectName(u"url_check_widget_name")
        self.url_check_widget_name.setGeometry(QRect(240, 50, 111, 31))
        self.url_check_widget_name.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")

        self.retranslateUi(url_check_widget)

        QMetaObject.connectSlotsByName(url_check_widget)
    # setupUi

    def retranslateUi(self, url_check_widget):
        url_check_widget.setWindowTitle(QCoreApplication.translate("url_check_widget", u"Form", None))
        self.url_check_widget_check.setText("")
        self.url_check_widget_name.setText(QCoreApplication.translate("url_check_widget", u"URL Check ", None))
    # retranslateUi

