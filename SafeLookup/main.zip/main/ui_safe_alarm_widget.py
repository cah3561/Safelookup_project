# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'safe_alarm_widgetpteLiS.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import res_1_rc

class Ui_safe_alarm_widget(object):
    def setupUi(self, safe_alarm_widget):
        if not safe_alarm_widget.objectName():
            safe_alarm_widget.setObjectName(u"safe_alarm_widget")
        safe_alarm_widget.resize(269, 181)
        safe_alarm_widget.setStyleSheet(u"border-image: url(:/main/Desktop - 1.png);")
        self.safe_alarm_widget_close = QPushButton(safe_alarm_widget)
        self.safe_alarm_widget_close.setObjectName(u"safe_alarm_widget_close")
        self.safe_alarm_widget_close.setGeometry(QRect(80, 50, 111, 71))
        self.safe_alarm_widget_close.setCursor(QCursor(Qt.PointingHandCursor))
        self.safe_alarm_widget_close.setStyleSheet(u"border-image: url(:/main/00 Button (10).png);")

        self.retranslateUi(safe_alarm_widget)

        QMetaObject.connectSlotsByName(safe_alarm_widget)
    # setupUi

    def retranslateUi(self, safe_alarm_widget):
        safe_alarm_widget.setWindowTitle(QCoreApplication.translate("safe_alarm_widget", u"Form", None))
        self.safe_alarm_widget_close.setText("")
    # retranslateUi

