# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'virus_wigetpcmhtR.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import res_1_rc

class Ui_virus_widget_main(object):
    def setupUi(self, virus_widget_main):
        if not virus_widget_main.objectName():
            virus_widget_main.setObjectName(u"virus_widget_main")
        virus_widget_main.resize(837, 547)
        virus_widget_main.setStyleSheet(u"border-image: url(:/main/Desktop - 1.png);")
        self.virus_widget_name_logo = QLabel(virus_widget_main)
        self.virus_widget_name_logo.setObjectName(u"virus_widget_name_logo")
        self.virus_widget_name_logo.setGeometry(QRect(350, 30, 121, 51))
        self.virus_widget_name_logo.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")
        self.virus_widget_name_logo.setAlignment(Qt.AlignCenter)
        self.virus_widget_check = QPushButton(virus_widget_main)
        self.virus_widget_check.setObjectName(u"virus_widget_check")
        self.virus_widget_check.setGeometry(QRect(580, 410, 61, 31))
        self.virus_widget_check.setStyleSheet(u"\n"
"border-image: url(:/main/Button-New.png);")
        self.virus_widget_bring = QListWidget(virus_widget_main)
        self.virus_widget_bring.setObjectName(u"virus_widget_bring")
        self.virus_widget_bring.setGeometry(QRect(240, 280, 331, 161))
        self.virus_widget_bring.setAcceptDrops(True)
        self.virus_widget_bring.setDragEnabled(True)
        self.virus_widget_bring.setDragDropOverwriteMode(True)
        self.virus_widget_upload = QToolButton(virus_widget_main)
        self.virus_widget_upload.setObjectName(u"virus_widget_upload")
        self.virus_widget_upload.setGeometry(QRect(590, 380, 24, 22))
        self.virus_widget_bring_logo = QLabel(virus_widget_main)
        self.virus_widget_bring_logo.setObjectName(u"virus_widget_bring_logo")
        self.virus_widget_bring_logo.setGeometry(QRect(380, 350, 51, 31))
        self.virus_widget_bring_logo.setStyleSheet(u"border-image: url(:/main/Viruscheck_icon.png);")
        self.virus_widget_logo = QFrame(virus_widget_main)
        self.virus_widget_logo.setObjectName(u"virus_widget_logo")
        self.virus_widget_logo.setGeometry(QRect(230, 130, 381, 91))
        self.virus_widget_logo.setStyleSheet(u"border-image: url(:/main/Safe Lookup.png);")
        self.virus_widget_logo.setFrameShape(QFrame.NoFrame)

        self.retranslateUi(virus_widget_main)

        QMetaObject.connectSlotsByName(virus_widget_main)
    # setupUi

    def retranslateUi(self, virus_widget_main):
        virus_widget_main.setWindowTitle(QCoreApplication.translate("virus_widget_main", u"Form", None))
        self.virus_widget_name_logo.setText(QCoreApplication.translate("virus_widget_main", u"Virus Check", None))
        self.virus_widget_check.setText("")
        self.virus_widget_upload.setText(QCoreApplication.translate("virus_widget_main", u"...", None))
        self.virus_widget_bring_logo.setText("")
    # retranslateUi

