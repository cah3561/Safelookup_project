# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'help_widgetSxFwNe.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *
import sys
import res_1_rc

class Ui_help_widget(object):
    def setupUi(self, help_widget):
        if not help_widget.objectName():
            help_widget.setObjectName(u"help_widget")
        help_widget.resize(603, 634)
        help_widget.setStyleSheet(u"border-image: url(./Desktop - 1.png);")
        self.help_widget_logo = QFrame(help_widget)
        self.help_widget_logo.setObjectName(u"help_widget_logo")
        self.help_widget_logo.setGeometry(QRect(110, 10, 381, 91))
        self.help_widget_logo.setStyleSheet(u"border-image: url(./Safe Lookup.png);")
        self.help_widget_logo.setFrameShape(QFrame.NoFrame)
        self.help_widget_name = QLabel(help_widget)
        self.help_widget_name.setObjectName(u"help_widget_name")
        self.help_widget_name.setGeometry(QRect(250, 100, 91, 31))
        self.help_widget_name.setStyleSheet(u"font: 16pt \"\uace0\ub3c4 B\";\n"
"color: rgb(255, 255, 255);")
        self.help_widget_name.setAlignment(Qt.AlignCenter)
        self.help_widget_text = QTextBrowser(help_widget)
        self.help_widget_text.setObjectName(u"help_widget_text")
        self.help_widget_text.setGeometry(QRect(80, 150, 441, 441))

        self.retranslateUi(help_widget)

        QMetaObject.connectSlotsByName(help_widget)
    # setupUi

    def retranslateUi(self, help_widget):
        help_widget.setWindowTitle(QCoreApplication.translate("help_widget", u"Form", None))
        self.help_widget_name.setText(QCoreApplication.translate("help_widget", u"\ub3c4\uc6c0\ub9d0", None))
    # retranslateUi

if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    MainWindow = QMainWindow()
    ui = Ui_help_widget()
    ui.setupUi(MainWindow)
    
    MainWindow.show()
    
    sys.exit(app.exec())
