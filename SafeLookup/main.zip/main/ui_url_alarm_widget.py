# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'url_alarm_widgetqgvfXp.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import res_1_rc

class Ui_url_alarm(object):
    def setupUi(self, url_alarm):
        if not url_alarm.objectName():
            url_alarm.setObjectName(u"url_alarm")
        url_alarm.resize(276, 181)
        url_alarm.setStyleSheet(u"border-image: url(:/main/Desktop - 1.png);")
        self.url_alarm_war = QPushButton(url_alarm)
        self.url_alarm_war.setObjectName(u"url_alarm_war")
        self.url_alarm_war.setGeometry(QRect(80, 80, 111, 71))
        self.url_alarm_war.setCursor(QCursor(Qt.PointingHandCursor))
        self.url_alarm_war.setStyleSheet(u"border-image: url(:/main/00 Button (11).png);")
        self.url_alarm_logo = QFrame(url_alarm)
        self.url_alarm_logo.setObjectName(u"url_alarm_logo")
        self.url_alarm_logo.setGeometry(QRect(110, 20, 41, 41))
        self.url_alarm_logo.setStyleSheet(u"border-image: url(:/main/alarm_icon.png);")
        self.url_alarm_logo.setFrameShape(QFrame.NoFrame)

        self.retranslateUi(url_alarm)

        QMetaObject.connectSlotsByName(url_alarm)
    # setupUi

    def retranslateUi(self, url_alarm):
        url_alarm.setWindowTitle(QCoreApplication.translate("url_alarm", u"Form", None))
        self.url_alarm_war.setText("")
    # retranslateUi

