# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'descript_widgetNNJMwF.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from PySide2.QtWebEngineWidgets import QWebEngineView


import res_1_rc

class Ui_des_widget(object):
    def setupUi(self, des_widget):
        if not des_widget.objectName():
            des_widget.setObjectName(u"des_widget")
        des_widget.resize(673, 472)
        des_widget.setStyleSheet(u"border-image: url(:/main/Desktop - 1.png);")
        self.des_widget_name = QLabel(des_widget)
        self.des_widget_name.setObjectName(u"des_widget_name")
        self.des_widget_name.setGeometry(QRect(200, 30, 261, 31))
        font = QFont()
        font.setFamily(u"\uace0\ub3c4 B")
        font.setPointSize(22)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.des_widget_name.setFont(font)
        self.des_widget_name.setStyleSheet(u"color: rgb(204, 204, 204);\n"
"font: 22pt \"\uace0\ub3c4 B\";")
        self.des_widget_name.setAlignment(Qt.AlignCenter)
        self.des_widget_close = QPushButton(des_widget)
        self.des_widget_close.setObjectName(u"des_widget_close")
        self.des_widget_close.setGeometry(QRect(470, 30, 51, 41))
        self.des_widget_close.setCursor(QCursor(Qt.PointingHandCursor))
        self.des_widget_close.setStyleSheet(u"border-image: url(:/main/exit_icon.png);")
        self.des_widget_web = QWebEngineView(des_widget)
        self.des_widget_web.setObjectName(u"des_widget_web")
        self.des_widget_web.setGeometry(QRect(90, 90, 491, 351))
        self.des_widget_web.setUrl(QUrl(u"about:blank"))
        self.des_widget_scrollarea = QScrollArea(des_widget)
        self.des_widget_scrollarea.setObjectName(u"des_widget_scrollarea")
        self.des_widget_scrollarea.setGeometry(QRect(100, 100, 471, 331))
        self.des_widget_scrollarea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 471, 331))
        self.des_widget_scrollarea.setWidget(self.scrollAreaWidgetContents)

        self.retranslateUi(des_widget)

        QMetaObject.connectSlotsByName(des_widget)
    # setupUi

    def retranslateUi(self, des_widget):
        des_widget.setWindowTitle(QCoreApplication.translate("des_widget", u"Form", None))
#if QT_CONFIG(whatsthis)
        self.des_widget_name.setWhatsThis(QCoreApplication.translate("des_widget", u"<html><head/><body><p><br/></p></body></html>", None))
#endif // QT_CONFIG(whatsthis)
        self.des_widget_name.setText(QCoreApplication.translate("des_widget", u"Details of Reports", None))
        self.des_widget_close.setText("")
    # retranslateUi

